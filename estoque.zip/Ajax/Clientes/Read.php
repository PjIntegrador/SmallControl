<?php
session_start();
include_once '../../includes/config.php';
$message = '';

$Search = strip_tags(filter_input(INPUT_POST, 'searching', FILTER_SANITIZE_STRIPPED));

if(empty($Search)){
    $message = ['status'=> 'info', 'message'=> 'Por favor, preencha o campo de busca !', 'Redirect'=> ''];
    echo json_encode($message);
    return; 

$Read = $pdo->prepare("SELECT cliente_id, cliente_nome, cliente_email, cliente_status, cliente_cadastro FROM ".DB_CLIENTS." WHERE cliente_nome = :cliente_nome AND cliente_status = :cliente_status");
$Read->bindValue(':cliente_nome', $Search);
$Read->bindValue(':cliente_status', 1);
$Read->execute();

$Lines = $Read->rowCount();

if($Lines == 0){
    $message = ['status'=> 'info', 'message'=> 'Por favor, preencha o campo de busca !', 'Redirect'=> ''];
    echo json_encode($message);
    return; 
}
}